// ----------------------------------------------------------------------

export const uploadClasses = {
  upload: 'mnl__upload',
  uploadBox: 'mnl__upload__box',
  uploadAvatar: 'mnl__upload__avatar',
  uploadSinglePreview: 'mnl__upload__single__preview',
  uploadMultiPreview: 'mnl__upload__multi__preview',
  uploadRejectionFiles: 'mnl__upload__rejection__files',
};
