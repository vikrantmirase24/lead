export const STORAGE_KEY = 'access_token';
export const PORTAL_KEY = 'portal_key';
